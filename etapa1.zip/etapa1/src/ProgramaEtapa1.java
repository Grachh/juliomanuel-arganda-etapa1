
public class ProgramaEtapa1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Se pueden usar las constantes definidas en LibEtapa1 porque son 
		//		public	(visibles)
		//		static	(utilizables)
		//		final (constantes)
		System.out.println(LibEtapa1.rojo);
		System.out.println(LibEtapa1.avogadro);
		
		// TAREAS:
		//	1) Definir nuevas constantes
		//	2) Provad la necesidad de que sean public, static, final
		
		// Pruebas de las funciones o m�todos
		// ERRORES COMUNES:
		//	1. Se ponen m�s par�metros de los que se piden
		//		longitudCircunferencia (2.2,2.9)
		//	2. Confundir el punto con la coma. La coma separa argumentos !!!
		//	3. No hay que a�adir nombres de tipo:
		//			longitudCircunferencia (int 2.2)
		//	4. Si sale error (punto rojo) poned el rat�n encima y traducis
		//	5. El m�todo duplicado.
		//
		
		// LAS PRUEBAS 1 o 2.
		System.out.println (LibEtapa1.longitudCircunferencia(34.8));
		System.out.println (LibEtapa1.masaTierra);
		
		
	}

}
